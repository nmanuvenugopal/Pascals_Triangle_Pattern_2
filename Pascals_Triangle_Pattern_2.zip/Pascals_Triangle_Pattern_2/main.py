from math import factorial

def nCr(n, r):
    result = factorial(n)/(factorial(r) * factorial(n-r))
    return round(result)

num = int(input("Enter the number: "))

def print_pascals_triangle(loop_num):
    for i in range(0, loop_num):
        for j in range(0, i + 1):
            print(nCr(i, j), end=' ')
        print("")

print_pascals_triangle(num)